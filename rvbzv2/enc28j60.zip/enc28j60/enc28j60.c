/*********************************************
 * vim:sw=8:ts=8:si:et
 * To use the above modeline in vim you must have "set modeline" in your .vimrc
 * Author: Guido Socher 
 * Copyright: GPL V2
 * http://www.gnu.org/licenses/gpl.html
 *
 * Based on the enc28j60.c file from the AVRlib library by Pascal Stang.
 * For AVRlib See http://www.procyonengineering.com/
 * Used with explicit permission of Pascal Stang.
 *
 * Title: Microchip ENC28J60 Ethernet Interface Driver
 * Chip type           : ATMEGA88 with ENC28J60
 *********************************************/
 
 // Modified for XMEGA by BETZAH
 
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "enc28j60.h"
#include "../peripherals.h"


static uint8_t Enc28j60Bank;
static uint16_t gNextPacketPtr;


uint8_t ETH_TRANSCEIVE(uint8_t data)
{
	ETH_USART.DATA = (data);
	while(!(ETH_USART.STATUS & USART_TXCIF_bm));
	ETH_USART.STATUS |= USART_TXCIF_bm;
	return (ETH_USART.DATA);
}


uint8_t enc28j60ReadOp(uint8_t op, uint8_t address)
{
	uint8_t byte = 0;
	
	ETH_CS_ACTIVE();// issue read command
	ETH_TRANSCEIVE(op | (address & ADDR_MASK));
	byte = ETH_TRANSCEIVE(0x00);
	
	// do dummy read if needed (for mac and mii, see datasheet page 29)
	if(address & 0x80) byte = ETH_TRANSCEIVE(0x00);
	
	//Read data
	//while (ETH_USART.STATUS & USART_RXCIF_bm) byte = ETH_USART.DATA;
	
	ETH_CS_PASSIVE();
	return(byte);
}


void enc28j60WriteOp(uint8_t op, uint8_t address, uint8_t data)  
{
	ETH_CS_ACTIVE();
	
	ETH_TRANSCEIVE(op | (address & ADDR_MASK));
	ETH_TRANSCEIVE(data);
	
	ETH_CS_PASSIVE();
}

void enc28j60ReadBuffer(uint16_t len, uint8_t* data)
{
	ETH_CS_ACTIVE();
	
	ETH_TRANSCEIVE(ENC28J60_READ_BUF_MEM);
	
	while(len)
	{
		len--;
		(*data) = ETH_TRANSCEIVE(0x00);
		data++;
	}
	*data = '\0';
	ETH_CS_PASSIVE();
}

void enc28j60WriteBuffer(uint16_t len, uint8_t* data)
{
	ETH_CS_ACTIVE();
	ETH_TRANSCEIVE(ENC28J60_WRITE_BUF_MEM);
	
	while(len)
	{
		ETH_TRANSCEIVE((*data));
		data++;
		len--;
	}
	ETH_CS_PASSIVE();
}

uint8_t enc28j60Read(uint8_t address)
{
	// set the bank
	enc28j60SetBank(address);
	// do the read
	return enc28j60ReadOp(ENC28J60_READ_CTRL_REG, address);
}

void enc28j60Write(uint8_t address, uint8_t data)
{
	// set the bank
	enc28j60SetBank(address);
	// do the write
	enc28j60WriteOp(ENC28J60_WRITE_CTRL_REG, address, data);
}

// read PHY
uint16_t enc28j60PhyRead(uint8_t address)
{
	uint8_t byteL, byteH;
	
	// Set the right address and start the register read operation
	enc28j60Write(MIREGADR, address);
	enc28j60Write(MICMD, MICMD_MIIRD);

	// wait until the PHY read completes
	_delay_us(15);
	while(enc28j60Read(MISTAT) & MISTAT_BUSY); // optional but recommended

	// reset reading bit
	enc28j60Write(MICMD, 0x00);
	
	byteL = enc28j60ReadOp(ENC28J60_READ_CTRL_REG, MIRDL);
	byteH = enc28j60ReadOp(ENC28J60_READ_CTRL_REG, MIRDH);
	
	return (((uint16_t)byteH << 8) | (uint16_t)byteL);
}

void enc28j60PhyWrite(uint8_t address, uint16_t data)
{
	// set the PHY register address
	enc28j60Write(MIREGADR, address);
	// write the PHY data
	enc28j60Write(MIWRL, (data & 0xFF));
	enc28j60Write(MIWRH, data>>8);
	
	// wait until the PHY write completes
	_delay_us(15);
	while(enc28j60Read(MISTAT) & MISTAT_BUSY);
}

void enc28j60SetBank(uint8_t address)
{
	uint8_t newBank = address & BANK_MASK;
	
	if(newBank != Enc28j60Bank) // set the bank (if needed)
	{
		enc28j60WriteOp(ENC28J60_BIT_FIELD_CLR, ECON1, (ECON1_BSEL1|ECON1_BSEL0));
		enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, ECON1, newBank >> 5);
		Enc28j60Bank = newBank;
	}
}

void enc28j60clkout(uint8_t clk)
{
	//setup clkout: 2 is 12.5MHz:
	enc28j60Write(ECOCON, clk & 0x7);
}

// read the revision of the chip:
uint8_t enc28j60getrev(void)
{
	return(enc28j60Read(EREVID));
}

// link status
uint8_t enc28j60linkup(void)
{
	// bit 10 (= bit 3 in upper reg)
	return(enc28j60PhyRead(PHSTAT2) && (1 << 10));
}

void enc28j60Init(uint8_t* macaddr)
{
	// init GPIO
	PORTB.PIN3CTRL = PORT_OPC_PULLUP_gc; // Ethernet INT
	PORTD.PIN0CTRL = PORT_OPC_PULLUP_gc; // Ethernet CS
	PORTD.PIN1CTRL = PORT_OPC_PULLDOWN_gc; // Ethernet SCK
	PORTD.PIN2CTRL = PORT_OPC_PULLDOWN_gc; // Ethernet RX
	PORTD.PIN3CTRL = PORT_OPC_PULLDOWN_gc; // Ethernet TX
	PORTD.PIN4CTRL = PORT_OPC_PULLUP_gc; // Ethernet WOL
	PORTD.PIN5CTRL = PORT_OPC_PULLUP_gc; // Ethernet RST
	
	ETH_PORT.OUTCLR = ETH_PIN_SCK | ETH_PIN_MISO | ETH_PIN_MOSI;
	ETH_PORT.OUTSET = ETH_PIN_CS;
	
	ETH_PORT.DIRCLR	= ETH_PIN_MISO;
	ETH_PORT.DIRSET	= ETH_PIN_MOSI | ETH_PIN_SCK | ETH_PIN_CS;
	
	// init USART
	ETH_USART.BAUDCTRLA	= 1; // 32 / 4 = 8 MHz
	ETH_USART.BAUDCTRLB	= 0; // BSCALE, BSEL
	ETH_USART.CTRLC		= USART_CMODE_MSPI_gc; // SPI mode 0
	ETH_USART.CTRLA		= 0; // no interrupts
	ETH_USART.CTRLB		= USART_TXEN_bm | USART_RXEN_bm; // enable transmit
	
	// perform system reset
	enc28j60WriteOp(ENC28J60_SOFT_RESET, 0, ENC28J60_SOFT_RESET);
	_delay_ms(50);
	
	//Clear buffers
	//uint8_t byte; while (ETH_USART.STATUS & USART_RXCIF_bm) byte = ETH_USART.DATA;
	
	// check CLKRDY bit to see if reset is complete
    // The CLKRDY does not work. See Rev. B4 Silicon Errata point. Just wait.
	//while(!(enc28j60Read(ESTAT) & ESTAT_CLKRDY));
	
	// INITIALIZE BANK 0: receive buffer, start address
	// 16-bit transfers, must write low byte first
	
	gNextPacketPtr = RXSTART_INIT;
	// Rx start
	enc28j60Write(ERXSTL, RXSTART_INIT&0xFF);
	enc28j60Write(ERXSTH, RXSTART_INIT>>8);
	// set receive pointer address
	enc28j60Write(ERXRDPTL, RXSTART_INIT&0xFF);
	enc28j60Write(ERXRDPTH, RXSTART_INIT>>8);
	// RX end
	enc28j60Write(ERXNDL, RXSTOP_INIT&0xFF);
	enc28j60Write(ERXNDH, RXSTOP_INIT>>8);
	// TX start
	enc28j60Write(ETXSTL, TXSTART_INIT&0xFF);
	enc28j60Write(ETXSTH, TXSTART_INIT>>8);
	// TX end
	enc28j60Write(ETXNDL, TXSTOP_INIT&0xFF);
	enc28j60Write(ETXNDH, TXSTOP_INIT>>8);
	
	// INITIALIZE BANK 1: packet filter
	// For broadcast packets we allow only ARP packtets
	// All other packets should be unicast only for our mac (MAADR)
	// The pattern to match on is therefore
	// Type     ETH.DST
	// ARP      BROADCAST
	// 06 08 -- ff ff ff ff ff ff -> ip checksum for theses bytes=f7f9
	// in binary these poitions are:11 0000 0011 1111
	// This is hex 303F->EPMM0=0x3f,EPMM1=0x30
// 	enc28j60Write(ERXFCON, ERXFCON_UCEN|ERXFCON_CRCEN|ERXFCON_PMEN);
// 	enc28j60Write(EPMM0, 0x3f);
// 	enc28j60Write(EPMM1, 0x30);
// 	enc28j60Write(EPMCSL, 0xf9);
// 	enc28j60Write(EPMCSH, 0xf7);
	
	// INITIALIZE BANK 2
	// enable MAC receive
	enc28j60Write(MACON1, MACON1_MARXEN|MACON1_TXPAUS|MACON1_RXPAUS);
	// bring MAC out of reset
	enc28j60Write(MACON2, 0x00);
	// enable automatic padding to 60bytes and CRC operations
	enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, MACON3, MACON3_PADCFG0|MACON3_TXCRCEN|MACON3_FRMLNEN);
	// set inter-frame gap (non-back-to-back)
	enc28j60Write(MAIPGL, 0x12);
	enc28j60Write(MAIPGH, 0x0C);
	// set inter-frame gap (back-to-back)
	enc28j60Write(MABBIPG, 0x12);
	// Set the maximum packet size which the controller will accept
	// Do not send packets longer than MAX_FRAMELEN:
	enc28j60Write(MAMXFLL, MAX_FRAMELEN&0xFF);	
	enc28j60Write(MAMXFLH, MAX_FRAMELEN>>8);
	
	// INITIALIZE BANK 3
	// write MAC address 
	// NOTE: MAC address in ENC28J60 is byte-backward
	enc28j60Write(MAADR5, macaddr[0]);
	enc28j60Write(MAADR4, macaddr[1]);
	enc28j60Write(MAADR3, macaddr[2]);
	enc28j60Write(MAADR2, macaddr[3]);
	enc28j60Write(MAADR1, macaddr[4]);
	enc28j60Write(MAADR0, macaddr[5]);
		
	// no loopback of transmitted frames
	enc28j60PhyWrite(PHCON2, PHCON2_HDLDIS);
	// switch to bank 0
	enc28j60SetBank(ECON1);
	// enable interrutps
	enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, EIE, EIE_INTIE|EIE_PKTIE);
	// enable packet reception
	enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, ECON1, ECON1_RXEN);

}

// just probe if there might be a packet
uint8_t enc28j60hasRxPkt(void)
{
	if( enc28j60Read(EPKTCNT) == 0 ){
		return(0);
	}
	return(1);
}

void enc28j60PacketSend(uint16_t len, uint8_t* packet)
{
	// Check no transmit in progress
	while (enc28j60ReadOp(ENC28J60_READ_CTRL_REG, ECON1) & ECON1_TXRTS)
	{
		// Reset the transmit logic problem. See Rev. B4 Silicon Errata point 12.
		if( (enc28j60Read(EIR) & EIR_TXERIF) ) {
			enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, ECON1, ECON1_TXRST);
			enc28j60WriteOp(ENC28J60_BIT_FIELD_CLR, ECON1, ECON1_TXRST);
		}
	}
	// Set the write pointer to start of transmit buffer area
	enc28j60Write(EWRPTL, TXSTART_INIT&0xFF);
	enc28j60Write(EWRPTH, TXSTART_INIT>>8);
	// Set the TXND pointer to correspond to the packet size given
	enc28j60Write(ETXNDL, (TXSTART_INIT+len)&0xFF);
	enc28j60Write(ETXNDH, (TXSTART_INIT+len)>>8);
	// write per-packet control byte (0x00 means use macon3 settings)
	enc28j60WriteOp(ENC28J60_WRITE_BUF_MEM, 0, 0x00);
	// copy the packet into the transmit buffer
	enc28j60WriteBuffer(len, packet);
	// send the contents of the transmit buffer onto the network
	enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, ECON1, ECON1_TXRTS);
}


// Gets a packet from the network receive buffer, if one is available.
// The packet will by headed by an ethernet header.
//      maxlen  The maximum acceptable length of a retrieved packet.
//      packet  Pointer where packet data should be stored.
// Returns: Packet length in bytes if a packet was retrieved, zero otherwise.
uint16_t enc28j60PacketReceive(uint16_t maxlen, uint8_t* packet)
{
	uint16_t rxstat;
	uint16_t len;
	// check if a packet has been received and buffered
	//if( !(enc28j60Read(EIR) & EIR_PKTIF) ){
	// The above does not work. See Rev. B4 Silicon Errata point 6.
	if( enc28j60Read(EPKTCNT) ==0 ){
		return(0);
	}

	// Set the read pointer to the start of the received packet
	enc28j60Write(ERDPTL, (gNextPacketPtr &0xFF));
	enc28j60Write(ERDPTH, (gNextPacketPtr)>>8);
	// read the next packet pointer
	gNextPacketPtr  = enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0);
	gNextPacketPtr |= enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0)<<8;
	// read the packet length (see datasheet page 43)
	len  = enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0);
	len |= enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0)<<8;
	len-=4; //remove the CRC count
	// read the receive status (see datasheet page 43)
	rxstat  = enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0);
	rxstat |= ((uint16_t)enc28j60ReadOp(ENC28J60_READ_BUF_MEM, 0))<<8;
	// limit retrieve length
	if (len>maxlen-1){
		len=maxlen-1;
	}
	// check CRC and symbol errors (see datasheet page 44, table 7-3):
	// The ERXFCON.CRCEN is set by default. Normally we should not
	// need to check this.
	if ((rxstat & 0x80)==0){
		// invalid
		len=0;
	}else{
		// copy the packet from the receive buffer
		enc28j60ReadBuffer(len, packet);
	}
	// Move the RX read pointer to the start of the next received packet
	// This frees the memory we just read out
	enc28j60Write(ERXRDPTL, (gNextPacketPtr &0xFF));
	enc28j60Write(ERXRDPTH, (gNextPacketPtr)>>8);
	// Move the RX read pointer to the start of the next received packet
	// This frees the memory we just read out.
	// However, compensate for the errata point 13, rev B4: enver write an even address!
	if ((gNextPacketPtr - 1 < RXSTART_INIT) || (gNextPacketPtr -1 > RXSTOP_INIT)) {
		enc28j60Write(ERXRDPTL, (RXSTOP_INIT)&0xFF);
		enc28j60Write(ERXRDPTH, (RXSTOP_INIT)>>8);
	} else {
		enc28j60Write(ERXRDPTL, (gNextPacketPtr-1)&0xFF);
		enc28j60Write(ERXRDPTH, (gNextPacketPtr-1)>>8);
	}
	// decrement the packet counter indicate we are done with this packet
	enc28j60WriteOp(ENC28J60_BIT_FIELD_SET, ECON2, ECON2_PKTDEC);
	return(len);
}

